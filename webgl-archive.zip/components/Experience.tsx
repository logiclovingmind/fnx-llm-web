'use client';

import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';
import World from './World';

export default function Experience() {
  return (
    <div className="canvas-shell">
      <Canvas
        gl={{
          antialias: true,
          powerPreference: 'high-performance',
          alpha: false,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.0,
        }}
        dpr={[1, 1.6]}
        camera={{ fov: 58, near: 0.1, far: 600, position: [0, 0, 62] }}
        onCreated={({ gl }) => gl.setClearColor('#070318', 1)}
      >
        <World />
      </Canvas>
    </div>
  );
}
