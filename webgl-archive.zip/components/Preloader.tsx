'use client';

import { useEffect, useRef, useState } from 'react';
import { useExperience } from '@/lib/store';
import Logo from './Logo';

const MIN_SHOW = 600; // ms — avoid a flash on fast machines

export default function Preloader() {
  const ready = useExperience((s) => s.ready);
  const [out, setOut] = useState(false);
  const [gone, setGone] = useState(false);
  const mountAt = useRef(performance.now());

  useEffect(() => {
    if (!ready) return;
    const elapsed = performance.now() - mountAt.current;
    const wait = Math.max(0, MIN_SHOW - elapsed);
    const t1 = setTimeout(() => setOut(true), wait);
    const t2 = setTimeout(() => setGone(true), wait + 820);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [ready]);

  if (gone) return null;

  // pure DOM cover — no second WebGL context. Masks the scene's compile/warmup,
  // then wipes up once the world reports ready.
  return (
    <div className={`preloader ${out ? 'out' : ''}`}>
      <div className="pl-center">
        <div className="pl-mark">
          <span className="pl-sparks" aria-hidden>
            {Array.from({ length: 12 }).map((_, i) => (
              <i key={i} style={{ ['--a' as string]: `${(360 / 12) * i}deg` }} />
            ))}
          </span>
          <Logo size={104} className="pl-logo" />
        </div>
      </div>
    </div>
  );
}
