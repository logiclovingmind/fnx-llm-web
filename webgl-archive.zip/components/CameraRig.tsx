'use client';

import { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { useExperience } from '@/lib/store';

// Per-scene camera keyframes (z depth + y height), ported from the standalone.
const CAM = [
  { z: 62, y: 0 }, // chaos
  { z: 60, y: 14 }, // leak (look down the funnel)
  { z: 40, y: 0 }, // intelligence (close)
  { z: 54, y: 6 }, // automation
  { z: 96, y: 10 }, // scale (pull back, vast)
  { z: 64, y: 4 }, // skyline (push in for a dense, near-level hero view of the city)
];

function camAt(prog: number) {
  const g = Math.min(prog * 5, 4.9999);
  const i = Math.floor(g);
  const f = g - i;
  const a = CAM[i];
  const b = CAM[Math.min(i + 1, 5)];
  const e = f * f * (3 - 2 * f); // smoothstep
  return { z: a.z + (b.z - a.z) * e, y: a.y + (b.y - a.y) * e };
}

const damp = (cur: number, to: number, rate: number, dt: number) =>
  cur + (to - cur) * (1 - Math.exp(-rate * dt));

const INTRO_DUR = 2.6; // seconds — cinematic push-in from deep space
const INTRO_Z = 210; // camera starts pulled way back
const easeOutCubic = (x: number) => 1 - Math.pow(1 - x, 3);

const SETTLE_FRAMES = 4; // render a few warm frames after link before revealing

export default function CameraRig() {
  const { camera, gl, scene } = useThree();
  const prog = useRef(0);
  const introStart = useRef<number | null>(null);
  const frames = useRef(0);
  const compiled = useRef(false);
  const settle = useRef(0);

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const target = useExperience.getState().progress;
    prog.current = damp(prog.current, target, 4.5, dt);

    const cam = camAt(prog.current);

    // Warm up behind the loader. The hitch isn't fillrate — it's shader program
    // *linking*: gl.compile() kicks off compilation but with parallel-shader-
    // compile the link finishes a few frames later, often mid push-in. compileAsync
    // resolves only once programs are truly link-complete; we then render a few
    // settle frames (warms buffer/texture uploads + the postprocessing passes)
    // before flipping ready, so the reveal + push-in run on an already-hot pipeline.
    frames.current += 1;
    if (frames.current === 1) {
      const r = (gl as unknown as {
        compileAsync?: (s: THREE.Scene, c: THREE.Camera) => Promise<unknown>;
      }).compileAsync?.(scene, camera);
      if (r && typeof (r as Promise<unknown>).then === 'function') {
        (r as Promise<unknown>).then(() => {
          compiled.current = true;
        });
      } else {
        gl.compile(scene, camera);
        compiled.current = true;
      }
    }
    if (compiled.current) settle.current += 1;
    if (compiled.current && settle.current >= SETTLE_FRAMES && !useExperience.getState().ready) {
      useExperience.getState().setReady(true);
    }
    const entered = useExperience.getState().ready;
    if (entered && introStart.current === null) {
      introStart.current = state.clock.elapsedTime;
    }
    const it =
      introStart.current === null
        ? 0
        : (state.clock.elapsedTime - introStart.current) / INTRO_DUR;
    const intro = it < 1 ? easeOutCubic(THREE.MathUtils.clamp(it, 0, 1)) : 1;
    const targetZ = THREE.MathUtils.lerp(INTRO_Z, cam.z, intro);

    camera.position.x = damp(camera.position.x, 0, 3, dt);
    camera.position.y = damp(camera.position.y, cam.y * intro, 3.4, dt);
    camera.position.z =
      intro < 1 ? targetZ : damp(camera.position.z, cam.z, 3.4, dt);
    camera.lookAt(0, 0, 0);
  });

  return null;
}
