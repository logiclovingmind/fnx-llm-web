// Brand-mark backdrop — one oversized 3D logo anchored off a section edge and
// cropped by it. Editorial, intentional, never busy. Position/size/mask per
// variant live in globals.css (.logo-bleed--*).

const VARIANTS = ['hero', 'a', 'b', 'c', 'final'] as const;
type Variant = (typeof VARIANTS)[number];

export default function LogoField({ variant = 'a' }: { variant?: Variant }) {
  return (
    <div className={`art logo-bleed logo-bleed--${variant}`} aria-hidden>
      <img src="/logo-3d.png" alt="" loading={variant === 'hero' ? 'eager' : 'lazy'} decoding="async" />
    </div>
  );
}
