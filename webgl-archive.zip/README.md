# WebGL experience archive

The original immersive WebGL/Three.js pipeline from the Logic Loving Mind site,
pulled out when the live site moved to a pure DOM/CSS build. Kept here so it can
be reused in another project.

## Entry point
`components/Experience.tsx` → `World.tsx` → Background, CameraRig, Core, Effects,
Ingest, Particles.

## Files
- components/: Experience, World, Background, Particles, Core, Ingest, CameraRig,
  Effects, Preloader, SmoothScroll, Overlay, HeroBubbles, HumanLimits, LogoField
- lib/: shaders.ts, formations.ts, ingest.ts, store.ts (zustand scroll/ready state)

## NOT included (shared with the live DOM site — copy from the main repo if needed)
- `components/Logo.tsx` — used live by the DOM site too
- `lib/scenes.ts` — BRAND constants + scene copy, used live

## Dependencies to reinstall in the target project
@react-three/fiber, @react-three/drei, @react-three/postprocessing, three, zustand
(plus lenis if SmoothScroll is used).
